package com.starfall.crystal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class StarfallCrystalMod implements ModInitializer {
    public static final String MOD_ID = "starfall_crystal";

    public static final Item STAR_CRYSTAL = Registry.register(
        Registries.ITEM,
        new Identifier(MOD_ID, "star_crystal"),
        new Item(new Item.Settings())
    );

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS)
            .register(entries -> entries.add(STAR_CRYSTAL));
    }
}
