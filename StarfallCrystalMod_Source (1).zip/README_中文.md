# 星辉水晶模组（源码项目）

目标版本：Minecraft Java 版 1.20.1  
模组框架：Fabric  
Java：17

## 当前内容
- 新物品：星辉水晶碎片（Star Crystal Shard）
- 物品会显示在创造模式的“材料”分类中
- 提供中文、英文名称和自定义物品纹理
- Fabric 1.20.1 项目源码

## 重要说明
这是**模组源码工程**，不是已经编译好的 `.jar` 文件。需要联网下载 Gradle/Fabric/Minecraft 依赖后编译，才能得到可安装的模组 JAR。
本项目尚未在此环境中执行 Gradle 构建或游戏内测试。

## 编译方式
在安装了 Java 17 和 Gradle 的电脑或兼容开发环境中：
1. 解压项目。
2. 在项目目录执行 `gradle build`。
3. 成功后，在 `build/libs/` 中找到 `starfall-crystal-mod-1.0.0.jar`（或同目录下的主 JAR）。

## 安卓手机安装
如果你使用支持 Fabric 的 Minecraft Java 版安卓启动器：
1. 先安装并运行 Minecraft 1.20.1。
2. 为该版本安装 Fabric Loader。
3. 将编译好的模组 `.jar` 放入该游戏实例的 `mods` 文件夹。
4. 启动游戏。若使用 Fabric API，请同时将与 Minecraft 1.20.1 对应的 Fabric API JAR 放入 `mods` 文件夹。

## 测试物品
进入创造模式，在“材料”分类寻找“星辉水晶碎片”。
也可在启用作弊的世界输入：
`/give @p starfall_crystal:star_crystal 1`

## 下一步可扩展
可继续加入矿石方块、世界生成、工具、盔甲、合成配方、音效和粒子效果。
